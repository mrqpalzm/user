from fastapi import FastAPI, Form, Request, UploadFile, File
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware
import sqlite3, hashlib, shutil, pandas as pd

app = FastAPI()
app.add_middleware(SessionMiddleware, secret_key='your-secret-key')
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

def get_db():
    return sqlite3.connect("user_data.db")

def verify_user(username, password, db):
    h = hashlib.sha256(password.encode()).hexdigest()
    user = db.execute("SELECT * FROM users WHERE username=? AND password=?", (username, h)).fetchone()
    return user

@app.get("/", response_class=HTMLResponse)
def login_form(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

@app.post("/login", response_class=HTMLResponse)
def login(request: Request, username: str = Form(...), password: str = Form(...)):
    db = get_db()
    user = verify_user(username, password, db)
    db.close()
    if user:
        request.session['user'] = username
        request.session['is_admin'] = bool(user[3])
        return RedirectResponse("/search", status_code=302)
    return templates.TemplateResponse("login.html", {"request": request, "error": "Invalid credentials"})

@app.get("/search", response_class=HTMLResponse)
def search_page(request: Request):
    if "user" not in request.session:
        return RedirectResponse("/", status_code=302)
    return templates.TemplateResponse("search.html", {"request": request})

@app.post("/search", response_class=HTMLResponse)
def search(request: Request, keyword: str = Form(...)):
    if "user" not in request.session:
        return RedirectResponse("/", status_code=302)
    db = get_db()
    rows = db.execute("""
        SELECT * FROM records WHERE 
        name LIKE ? OR 
        birth_id LIKE ? OR 
        father LIKE ? OR 
        mother LIKE ?
    """, (f"%{keyword}%",)*4).fetchall()
    db.close()
    return templates.TemplateResponse("search.html", {"request": request, "results": rows})

@app.get("/admin", response_class=HTMLResponse)
def admin_page(request: Request):
    if not request.session.get("is_admin"):
        return RedirectResponse("/", status_code=302)
    return templates.TemplateResponse("admin.html", {"request": request})

@app.post("/upload", response_class=HTMLResponse)
def upload_file(request: Request, file: UploadFile = File(...)):
    if not request.session.get("is_admin"):
        return RedirectResponse("/", status_code=302)
    filepath = f"temp_upload.xlsx"
    with open(filepath, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    df = pd.read_excel(filepath)
    df.columns = ['birth_id', 'ward', 'name', 'dob', 'mother', 'father', 'address']
    db = get_db()
    db.execute("DELETE FROM records")
    for _, row in df.iterrows():
        db.execute("INSERT INTO records (birth_id, ward, name, dob, mother, father, address) VALUES (?, ?, ?, ?, ?, ?, ?)", tuple(row))
    db.commit()
    db.close()
    return templates.TemplateResponse("admin.html", {"request": request, "message": "Data updated successfully."})
